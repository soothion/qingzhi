$(document).ready(function(){
		$("#twitter li:not(:first)").css("display","none");
		var B=$("#twitter li:last");
		var C=$("#twitter li:first");
		setInterval(function(){
			if(B.is(":visible")){
				C.fadeIn(500).addClass("in");B.hide()
			}else{
				$("#twitter li:visible").addClass("in");
				$("#twitter li.in").next().fadeIn(500);
				$("li.in").hide().removeClass("in")}
			},3000) //每3秒钟切换一条
})